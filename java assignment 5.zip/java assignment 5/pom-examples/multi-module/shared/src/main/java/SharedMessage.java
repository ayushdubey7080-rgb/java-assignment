public class SharedMessage { public String message() { return "Hello from shared module"; } }
