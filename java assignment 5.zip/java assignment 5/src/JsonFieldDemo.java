import java.lang.annotation.*;
import java.lang.reflect.Field;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface JsonField {
    String value();
}

class Person {
    @JsonField("full_name")
    private String name = "Asha";
    @JsonField("person_age")
    private int age = 20;
}

public class JsonFieldDemo {
    public static void main(String[] args) {
        for (Field field : Person.class.getDeclaredFields()) {
            JsonField annotation = field.getAnnotation(JsonField.class);
            String jsonName = annotation == null ? field.getName() : annotation.value();
            System.out.println(field.getName() + " -> JSON key: " + jsonName);
        }
    }
}
