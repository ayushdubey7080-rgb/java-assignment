import java.lang.annotation.*;
import java.lang.reflect.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE, ElementType.METHOD, ElementType.FIELD})
@interface CourseInfo {
    String course();
    int level() default 1;
}

@CourseInfo(course = "Java Annotations", level = 5)
class AnnotationSubject {
    @CourseInfo(course = "Reflection demo")
    public void show() {}
}

public class CustomAnnotationExamples {
    public static void main(String[] args) throws Exception {
        CourseInfo classInfo = AnnotationSubject.class.getAnnotation(CourseInfo.class);
        System.out.println(classInfo.course() + ", level " + classInfo.level());

        Method method = AnnotationSubject.class.getDeclaredMethod("show");
        CourseInfo methodInfo = method.getAnnotation(CourseInfo.class);
        System.out.println("Method course: " + methodInfo.course());
    }
}
