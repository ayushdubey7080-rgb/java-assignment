import java.lang.annotation.*;
import java.lang.reflect.Field;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
@interface MinLength {
    int value();
}

class User {
    @MinLength(5)
    String username = "Ayush";
}

public class MinLengthValidationDemo {
    public static void main(String[] args) throws Exception {
        User user = new User();
        for (Field field : user.getClass().getDeclaredFields()) {
            MinLength rule = field.getAnnotation(MinLength.class);
            if (rule != null) {
                field.setAccessible(true);
                Object value = field.get(user);
                int length = value == null ? 0 : value.toString().length();
                System.out.println(field.getName() + " valid: " + (length >= rule.value()));
            }
        }
    }
}
