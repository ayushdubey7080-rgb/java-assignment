import java.lang.annotation.*;
import java.lang.reflect.Method;
import java.util.List;
import java.util.ArrayList;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@Documented
@Inherited
@interface AuthorInfo {
    String author();
    String version() default "1.0";
    String[] tags() default {};
}

@AuthorInfo(author = "Student", version = "1.1", tags = {"Java", "Assignment"})
class SampleService {
    @Deprecated
    public void oldMethod() { System.out.println("Deprecated method"); }

    @SuppressWarnings("unchecked")
    public List<String> unsafeExample() {
        List raw = new ArrayList();
        raw.add("Java");
        return raw;
    }
}

public class AnnotationExamples {
    public static void main(String[] args) throws Exception {
        Class<?> c = SampleService.class;
        AuthorInfo info = c.getAnnotation(AuthorInfo.class);
        if (info != null) {
            System.out.println("Author: " + info.author());
            System.out.println("Version: " + info.version());
            System.out.println("Tags: " + String.join(", ", info.tags()));
        }

        Method m = c.getDeclaredMethod("oldMethod");
        System.out.println("Method is deprecated: " + m.isAnnotationPresent(Deprecated.class));
        System.out.println("Override is used on overriding methods; compiler verifies it.");
    }
}
