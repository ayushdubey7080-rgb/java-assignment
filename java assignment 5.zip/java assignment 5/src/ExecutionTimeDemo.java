import java.lang.annotation.*;
import java.lang.reflect.Method;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
@interface MeasureExecutionTime {}

class Task {
    @MeasureExecutionTime
    public void work() throws InterruptedException {
        Thread.sleep(150);
    }
}

public class ExecutionTimeDemo {
    public static void main(String[] args) throws Exception {
        Task task = new Task();
        Method method = Task.class.getMethod("work");
        if (method.isAnnotationPresent(MeasureExecutionTime.class)) {
            long start = System.nanoTime();
            method.invoke(task);
            long elapsed = System.nanoTime() - start;
            System.out.printf("Execution time: %.2f ms%n", elapsed / 1_000_000.0);
        }
    }
}
