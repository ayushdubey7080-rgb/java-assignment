# Java Assignment 5 — Module 5 Answers
**Degree:** Bachelor of Technology in Artificial Intelligence  
**University:** Amity University

This folder contains answers for the questions supplied in the assignment. The README provides theory answers and Maven XML examples. The `src/` folder contains runnable Java examples. Maven configuration examples are in `pom-examples/`.

## Java Annotations and Their Types

### 2. Purpose of annotations
Annotations add metadata to classes, methods, fields, parameters, and other program elements. They do not normally change behavior by themselves; compiler tools, annotation processors, or frameworks can read them and act accordingly. Examples include compiler checks (`@Override`), warnings (`@Deprecated`), and framework configuration.

### 3. Three built-in annotations
- `@Override`: tells the compiler that a method overrides a superclass/interface method.
- `@Deprecated`: marks an API as discouraged or scheduled for removal.
- `@SuppressWarnings`: asks the compiler to suppress specified warnings in a scope.

See `src/AnnotationExamples.java`.

### 4. `@Override` vs `@Deprecated`
`@Override` is a compile-time correctness check for overriding. `@Deprecated` marks a declaration as obsolete and causes use-site warnings (unless suppressed). They serve different purposes.

### 5. `@SuppressWarnings`
It suppresses selected compiler warnings in the annotated scope, such as `"unchecked"` or `"deprecation"`. Use it narrowly because it can hide genuine problems.
```java
@SuppressWarnings("unchecked")
List<String> names = (List<String>) (List<?>) new ArrayList<Integer>();
```
This cast is unsafe; suppressing the warning does not make it safe.

### 6. Meta-annotations
Meta-annotations are annotations that describe how another annotation behaves or where it can be used. Examples: `@Target`, `@Retention`, `@Documented`, `@Inherited`, `@Repeatable`, and `@Native`.

### 7. Java meta-annotations
- `@Target`: permitted declaration locations.
- `@Retention`: how long annotation information is retained.
- `@Documented`: includes annotation in generated Javadoc.
- `@Inherited`: allows a class annotation to be inherited from a superclass (not interfaces).
- `@Repeatable`: allows an annotation to be used more than once on the same element.
- `@Native`: marks a field as a constant usable by native code.

### 8. Runtime behavior
Annotations with `RetentionPolicy.RUNTIME` can be inspected using reflection. A framework may use them to inject dependencies, map routes, validate fields, or map objects to database tables. The annotation alone does not execute code.

### 9. Retention policies
- `SOURCE`: discarded by the compiler; available only in source code.
- `CLASS`: stored in the `.class` file but not necessarily available through runtime reflection. This is the default if `@Retention` is omitted.
- `RUNTIME`: stored in the class file and available through reflection.

### 10. Creating a custom annotation
Use `@interface`, then configure it with meta-annotations. Example:
```java
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface AuthorInfo {
    String author();
    String version() default "1.0";
}
```

### 11. `@Target`
`@Target` restricts where an annotation can be applied, for example `ElementType.TYPE`, `METHOD`, `FIELD`, `PARAMETER`, or `CONSTRUCTOR`. It prevents accidental use at unsupported locations.

### 12. `RUNTIME` vs `CLASS`
`RUNTIME` annotations can be queried by reflection while the program runs. `CLASS` annotations are written to bytecode but are not guaranteed to be visible to runtime reflection; tools can inspect the class file during build/bytecode processing.

### 13. Reflection
Use `Class.getAnnotation()`, `getDeclaredAnnotation()`, `getAnnotations()`, or `getDeclaredAnnotations()` to inspect annotations. For method annotations, first obtain a `Method` object using `getDeclaredMethod()`. Example: `src/AnnotationExamples.java`.

### 14. Marker vs single-value annotations
A marker annotation has no elements, e.g. `@Fast`. A single-value annotation has one element, conventionally named `value`, e.g. `@Role("admin")`.

### 15. Spring and Hibernate
Spring uses annotations such as `@Component`, `@Autowired`, `@RestController`, and `@RequestMapping` for component discovery, dependency injection, and web routing. Hibernate/JPA uses `@Entity`, `@Id`, `@Column`, and relationships to map Java classes to database tables. Frameworks inspect annotations and implement the behavior.

### 16. Annotation inheritance
Annotations are not inherited by default. `@Inherited` enables inheritance of a runtime annotation from a superclass to a subclass. It applies only to class annotations, not method/field annotations or interfaces.

### 17. Default values
An annotation element can declare a default with `default`. If the user omits that element, Java uses the default:
```java
public @interface Info { String version() default "1.0"; }
```

### 18. Annotation to validate string length
See `src/MinLengthValidationDemo.java`. It defines `@MinLength` and checks it through reflection. In production, validation should also handle nulls and use a validation framework when appropriate.

### 19. Repeatable annotations
`@Repeatable(Container.class)` allows the same annotation to appear multiple times on one element. See `src/RepeatableAnnotationDemo.java`.

### 20. `@Documented`
It tells Javadoc to include the annotated annotation in generated API documentation. Without it, the annotation is normally omitted from Javadoc output.

### 21. Compile-time processing
The compiler reads annotations while compiling. Annotation processors (based on `javax.annotation.processing` in older Java releases / `javax` package still used by standard JDK annotation processing) can inspect source elements and generate files or report errors/warnings. `SOURCE` annotations are only available during this phase.

## Creating Custom Annotations

### 23. `@MinLength`
See `src/MinLengthValidationDemo.java`. The annotation stores a minimum length; reflection checks the annotated field or value.

### 24. Author and version annotation
See `src/AnnotationExamples.java` (`@AuthorInfo`). It records metadata on a class.

### 25. Processing with `Annotation`
The `java.lang.annotation.Annotation` interface is the common superinterface of all annotation types. Reflection methods return annotation instances; call their declared elements (e.g. `author()`, `version()`) to read values.

### 26. Restrictions on annotation methods
Annotation elements:
- have no parameters;
- cannot declare a `throws` clause;
- cannot use `void` as the return type;
- must return permitted types: primitives, `String`, `Class`, enums, annotation types, or one-dimensional arrays of these;
- cannot have type parameters or be generic;
- may declare a default value.

### 27. Arrays as annotation values
Yes. Annotation elements may be arrays of permitted annotation element types:
```java
String[] tags() default {};
```
See `src/AnnotationExamples.java`.

### 28. `@JsonField`
See `src/JsonFieldDemo.java`. The custom annotation supplies a JSON property name. A serializer can inspect fields and use the annotation value. The demo illustrates metadata lookup; it is not a complete JSON parser/serializer.

### 29. Can annotations extend annotations?
No. Annotation types implicitly extend `java.lang.annotation.Annotation`, and Java does not allow an annotation type to extend another annotation type. Compose annotations by placing annotations on an annotation declaration or use repeatable/container patterns.

### 30. Reflection demonstration
See `src/AnnotationExamples.java`, which defines an annotation, applies it to a class, and reads it using reflection.

### 31. Annotation for method execution time
See `src/ExecutionTimeDemo.java`. An annotation can mark methods, but it does not measure time itself. A proxy, interceptor, aspect, or wrapper must detect the annotation and measure execution.

### 32. Missing `@Retention`
If `@Retention` is omitted, the default is `RetentionPolicy.CLASS`. The annotation is stored in the class file but is not available through normal runtime reflection.

## Maven Framework

### 34. Purpose of Maven
Maven is a build and project management tool. It standardizes project structure, compiles code, runs tests, packages applications, resolves dependencies, and supports plugins and reproducible builds.

### 35. `pom.xml`
The Project Object Model file describes project coordinates (`groupId`, `artifactId`, `version`), dependencies, properties, build plugins, packaging, and other configuration.

### 36. Local, central, and remote repositories
- Local repository: cached artifacts on the developer's machine, commonly `~/.m2/repository`.
- Central repository: Maven's default public repository for many published artifacts.
- Remote repository: any other repository server configured by an organization or project (may be private or public).

### 37. Adding a dependency
Add a `<dependency>` under `<dependencies>` in `pom.xml`, specifying group ID, artifact ID, and version. Example is in `pom-examples/spring-boot-pom.xml`.

### 38. Maven plugins
Plugins provide build tasks (goals), such as compiling, testing, packaging, generating reports, and deploying. Examples include compiler, Surefire, and WAR plugins.

### 39. Maven build lifecycle
A lifecycle is a sequence of phases. Running a later phase executes preceding phases in order. Maven has clean, default, and site lifecycles.

### 40. Default lifecycle phases
Common default lifecycle phases, in order:
`validate`, `initialize`, `generate-sources`, `process-sources`, `generate-resources`, `process-resources`, `compile`, `process-classes`, `generate-test-sources`, `process-test-sources`, `generate-test-resources`, `process-test-resources`, `test-compile`, `process-test-classes`, `test`, `prepare-package`, `package`, `pre-integration-test`, `integration-test`, `post-integration-test`, `verify`, `install`, `deploy`.

### 41. Configure Java version
Set `maven.compiler.release` (recommended for modern Java) or configure `maven-compiler-plugin` source/target. Example:
```xml
<properties><maven.compiler.release>17</maven.compiler.release></properties>
```

### 42. Goal vs phase
A phase is a lifecycle stage such as `package`. A goal is a specific plugin task, such as `compiler:compile`. A phase can invoke one or more goals; a goal can also be invoked directly.

### 43. Spring Boot `pom.xml`
See `pom-examples/spring-boot-pom.xml`. It uses the Spring Boot parent, starter dependency, and Spring Boot Maven plugin. Change the version to one compatible with your project/JDK before use.

## Repositories, Dependencies, and Plugins

### 45. Dependency version conflicts
Maven uses dependency mediation: generally the “nearest” dependency wins; if two versions are at the same depth, the first declaration wins. `dependencyManagement` can centrally control versions. Use `mvn dependency:tree` to inspect conflicts.

### 46. Transitive dependency
A transitive dependency is a dependency brought in by another dependency. Maven resolves and downloads it automatically unless excluded or otherwise managed.

### 47. Excluding a transitive dependency
Use `<exclusions>` inside the dependency that brings it in:
```xml
<dependency>
  <groupId>example</groupId><artifactId>library</artifactId><version>1.0</version>
  <exclusions>
    <exclusion><groupId>example</groupId><artifactId>unwanted</artifactId></exclusion>
  </exclusions>
</dependency>
```

### 48. `maven-compiler-plugin`
It compiles main and test Java source code and allows configuration of Java release/source/target, compiler options, and annotation processing.

### 49. Create a JAR
Set `<packaging>jar</packaging>` (the default) and run:
`mvn clean package`
The JAR is produced in the `target/` directory.

### 50. Configure a plugin
Declare it under `<build><plugins>`. Specify plugin coordinates, version, configuration, and executions if needed. Examples appear in the Spring Boot and Surefire POM files.

### 51. Multi-module Maven project
Create a parent POM with `<packaging>pom</packaging>` and list child module directories under `<modules>`. Each child has its own POM and references the parent. See `pom-examples/multi-module/`.

### 52. Dependency scopes
- `compile`: available in main compile, test compile, and runtime; default scope.
- `provided`: available for compilation and tests, expected to be supplied by the runtime/container; not packaged as a normal runtime dependency.
- `runtime`: not needed to compile main source, but available at runtime and tests.

### 53. Deploy to a remote repository
Configure repository credentials in `~/.m2/settings.xml` (do not commit passwords), configure `<distributionManagement>` in the POM, and run `mvn deploy`. The remote server must permit publishing.

### 54. Surefire unit test configuration
See `pom-examples/surefire-pom.xml`. Surefire runs unit tests during the Maven `test` phase. Tests commonly use names such as `*Test.java`.

## Practical Exercises

### 56. Maven project with annotations for input validation
Use a custom `@MinLength` annotation and a reflection-based validator (see `src/MinLengthValidationDemo.java`). Add the source to a Maven project and run it with `mvn compile` / `mvn exec:java` after configuring an exec plugin, or run the class from your IDE.

### 57. Demonstrate transitive dependencies
Add a library that depends on another library, then inspect the resolved graph using `mvn dependency:tree`. The dependency tree displays both direct and transitive dependencies. Avoid relying on an arbitrary library version in a submission; choose a compatible version.

### 58. Core Java app using annotations and Maven
Use the examples in `src/` and a Maven `pom.xml`. Custom annotations define metadata, reflection reads them, and Maven compiles/packages the application and manages any dependencies.

### 59. Web application with `maven-war-plugin`
Set `<packaging>war</packaging>` and configure `maven-war-plugin` under `<build><plugins>`. Run `mvn package`; the WAR is generated in `target/`. A web application also needs appropriate web framework/servlet setup.

### 60. Multi-module project with shared dependencies
Put common versions in the parent POM's `<dependencyManagement>` and plugin versions in `<pluginManagement>`. Child modules inherit these settings and declare only dependencies they actually use. Example in `pom-examples/multi-module/`.

---
## How to run the Java examples
From the `src` folder, compile:
```bash
javac AnnotationExamples.java CustomAnnotationExamples.java MinLengthValidationDemo.java JsonFieldDemo.java RepeatableAnnotationDemo.java ExecutionTimeDemo.java
```
Then run a demo, for example:
```bash
java AnnotationExamples
java MinLengthValidationDemo
```
The Maven files are examples/templates; adjust package names, versions, and Java release to your environment.
