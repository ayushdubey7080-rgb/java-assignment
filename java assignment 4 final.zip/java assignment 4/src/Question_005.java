import java.util.*;
import java.util.concurrent.*;

// Question 5: What is the difference between ? extends T and ? super T in generics? Provide an example of when to use each.
// Answer: Use ? extends T (upper bound) to read values as T; use ? super T (lower bound) to add T values. PECS: Producer Extends, Consumer Super.
class Question5 {
    public static void main(String[] args) {
        List<Integer> ints = new ArrayList<>(List.of(1,2)); List<? extends Number> producer=ints; Number n=producer.get(0); List<? super Integer> consumer=new ArrayList<Number>(); consumer.add(3);
    }
}
