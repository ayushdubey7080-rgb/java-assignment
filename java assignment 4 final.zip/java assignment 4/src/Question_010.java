import java.util.*;

// Question 10: Develop a user-defined generic class Stack<T> that provides standard stack operations like push(T item), pop(), and peek(). Demonstrate with integers and strings.
// Answer: A stack follows LIFO (last in, first out).
class GenericStack<T>{ private Deque<T> d=new ArrayDeque<>(); void push(T x){d.push(x);} T pop(){return d.pop();} T peek(){return d.peek();} }

class Question10 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
