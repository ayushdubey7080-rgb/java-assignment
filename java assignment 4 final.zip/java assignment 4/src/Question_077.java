import java.util.*;
import java.util.concurrent.*;

// Question 77: Peek at both ends.
// Answer: Use the relevant Java Collections API, select the appropriate interface/implementation, and demonstrate the requested operations.
class Question77 {
    public static void main(String[] args) {
        System.out.println("Refer to the answer comments above.");
    }
}
