import java.util.*;

// Question 8: Create a user-defined generic class Box<T> with methods addItem(T item) and getItem(). Demonstrate its usage with String and Integer types.
// Answer: Box<T> stores one value of type T and exposes typed add/get methods.
class Box<T>{ private T item; void addItem(T item){this.item=item;} T getItem(){return item;} }

class Question8 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
