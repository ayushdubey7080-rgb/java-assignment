import java.util.*;
import java.util.concurrent.*;

// Question 17: What is the purpose of the Comparator and Comparable interfaces in the java.util package?
// Answer: java.util contains utility classes and collection types such as List, Map, Set, Arrays, Collections, Scanner, and Random.
class Question17 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(Arrays.asList("A","B")); System.out.println(list);
    }
}
