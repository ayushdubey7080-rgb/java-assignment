import java.util.*;

// Question 9: Write a generic method swapElements that swaps two elements in an array. Demonstrate its usage with different data types.
// Answer: A generic swap exchanges two array positions.
class Question9 {
    static <T> void swapElements(T[] a,int i,int j){ T temp=a[i]; a[i]=a[j]; a[j]=temp; }
    public static void main(String[] args) {
        System.out.println("Generic helper method is defined above.");
    }
}
