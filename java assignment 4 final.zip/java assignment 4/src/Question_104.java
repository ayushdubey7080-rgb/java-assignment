import java.util.*;

// Question 104: Create a class LruCache<K, V> using LinkedHashMap to implement an LRU (Least Recently Used) cache.
// Answer: An LRU cache uses access-order LinkedHashMap and removes the eldest entry when size exceeds capacity.
class LruCache<K,V> extends LinkedHashMap<K,V>{ private final int cap; LruCache(int c){super(16,0.75f,true);cap=c;} protected boolean removeEldestEntry(Map.Entry<K,V> e){return size()>cap;} }

class Question104 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
