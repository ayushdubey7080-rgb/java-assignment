import java.util.*;
import java.util.concurrent.*;

// Question 91: Write a program using CopyOnWriteArrayList to iterate and modify a list safely in a multithreaded environment.
// Answer: CopyOnWriteArrayList copies its backing array on mutation; iteration uses a stable snapshot. It suits many reads and few writes, but writes are expensive.
class Question91 {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list=new CopyOnWriteArrayList<>(List.of(1,2)); for(Integer x:list){ list.add(3); System.out.println(x); }
    }
}
