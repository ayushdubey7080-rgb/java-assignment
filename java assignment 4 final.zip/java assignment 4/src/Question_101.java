import java.util.*;

// Question 101: Write a program to sort a list of custom objects (e.g., Student with name and marks) using a Comparator.
// Answer: Comparator compares custom objects using chosen fields.
class Student{String name; int marks; Student(String n,int m){name=n;marks=m;}} List<Student> s=new ArrayList<>(); s.sort(Comparator.comparingInt(x->x.marks));

class Question101 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
