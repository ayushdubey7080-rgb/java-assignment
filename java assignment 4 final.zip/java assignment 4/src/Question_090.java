import java.util.*;
import java.util.concurrent.*;

// Question 90: What are the differences between CopyOnWriteArrayList and ArrayList?
// Answer: CopyOnWriteArrayList copies its backing array on mutation; iteration uses a stable snapshot. It suits many reads and few writes, but writes are expensive.
class Question90 {
    public static void main(String[] args) {
        CopyOnWriteArrayList<Integer> list=new CopyOnWriteArrayList<>(List.of(1,2)); for(Integer x:list){ list.add(3); System.out.println(x); }
    }
}
