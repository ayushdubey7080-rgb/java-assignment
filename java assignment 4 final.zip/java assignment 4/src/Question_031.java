import java.util.*;
import java.util.concurrent.*;

// Question 31: Write a program to demonstrate the use of ArrayList for storing and iterating over elements.
// Answer: ArrayList is a resizable array-backed List.
class Question31 {
    public static void main(String[] args) {
        List<String> names=new ArrayList<>(); names.add("Asha"); names.add("Ravi"); for(String name:names) System.out.println(name);
    }
}
