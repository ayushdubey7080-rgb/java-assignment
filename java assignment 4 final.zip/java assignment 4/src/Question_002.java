import java.util.*;
import java.util.concurrent.*;

// Question 2: What is the purpose of generics in Java, and how do they improve type safety and code reusability?
// Answer: Generics allow classes, interfaces, and methods to work with types as parameters. They provide compile-time type safety, reduce casts, and promote reusable code.
class Question2 {
    public static void main(String[] args) {
        List<String> names = new ArrayList<>(); names.add("Java"); System.out.println(names.get(0));
    }
}
