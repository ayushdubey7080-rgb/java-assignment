import java.util.*;
import java.util.concurrent.*;

// Question 74: Implement a deque using the ArrayDeque class. Perform operations like:
// Answer: Deque supports insertion/removal at both ends. ArrayDeque is efficient; palindrome check compares characters removed from both ends.
class Question74 {
    public static void main(String[] args) {
        Deque<Character> d=new ArrayDeque<>(); String s="level"; for(char c:s.toCharArray()) d.addLast(c); boolean ok=true; while(d.size()>1) if(!d.removeFirst().equals(d.removeLast())) ok=false; System.out.println(ok);
    }
}
