import java.util.*;
import java.util.concurrent.*;

// Question 25: An enhanced for loop
// Answer: The enhanced for loop visits each element without using an index.
class Question25 {
    public static void main(String[] args) {
        for(Integer x: List.of(10,20,30)) System.out.println(x);
    }
}
