import java.util.*;
import java.util.concurrent.*;

// Question 33: How is the Stack class implemented, and how does it relate to the List interface?
// Answer: List is ordered and permits duplicates; Set contains unique elements; Queue represents elements waiting for processing, commonly FIFO.
class Question33 {
    public static void main(String[] args) {
        List<String> l=new ArrayList<>(); Set<String> s=new HashSet<>(); Queue<String> q=new LinkedList<>();
    }
}
