import java.util.*;
import java.util.concurrent.*;

// Question 114: Write a program to store a list of products and their prices in a TreeMap and display the products in sorted order by name.
// Answer: TreeMap stores keys in their natural or Comparator-defined sorted order.
class Question114 {
    public static void main(String[] args) {
        Map<Integer,String> m=new TreeMap<>(); m.put(3,"C"); m.put(1,"A"); m.put(2,"B"); System.out.println(m);
    }
}
