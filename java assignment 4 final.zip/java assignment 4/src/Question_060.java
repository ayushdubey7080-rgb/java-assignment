import java.util.*;
import java.util.concurrent.*;

// Question 60: Write a program to demonstrate the use of TreeMap for sorting keys.
// Answer: TreeMap stores keys in their natural or Comparator-defined sorted order.
class Question60 {
    public static void main(String[] args) {
        Map<Integer,String> m=new TreeMap<>(); m.put(3,"C"); m.put(1,"A"); m.put(2,"B"); System.out.println(m);
    }
}
