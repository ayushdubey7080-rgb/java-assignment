import java.util.*;
import java.util.concurrent.*;

// Question 82: What is the difference between BlockingQueue and PriorityQueue?
// Answer: PriorityQueue removes elements according to priority/natural ordering, not insertion order. By default, smallest value is removed first.
class Question82 {
    public static void main(String[] args) {
        PriorityQueue<Integer> pq=new PriorityQueue<>(List.of(5,1,3)); while(!pq.isEmpty()) System.out.println(pq.poll());
    }
}
