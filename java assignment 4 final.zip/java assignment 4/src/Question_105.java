import java.util.*;
import java.util.concurrent.*;

// Question 105: Implement a basic to-do list application using ArrayList to store tasks. Add functionality to add, remove, and display tasks.
// Answer: ArrayList can store tasks; add appends, remove deletes, and iteration displays tasks.
class Question105 {
    public static void main(String[] args) {
        List<String> tasks=new ArrayList<>(); tasks.add("Study Java"); tasks.add("Submit assignment"); tasks.remove("Study Java"); tasks.forEach(System.out::println);
    }
}
