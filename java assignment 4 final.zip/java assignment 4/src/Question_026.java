import java.util.*;
import java.util.concurrent.*;

// Question 26: A while loop with an Iterator
// Answer: Use hasNext() to test for another element and next() to retrieve it.
class Question26 {
    public static void main(String[] args) {
        Iterator<Integer> it=List.of(10,20,30).iterator(); while(it.hasNext()) System.out.println(it.next());
    }
}
