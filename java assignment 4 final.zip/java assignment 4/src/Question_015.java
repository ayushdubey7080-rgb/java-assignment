import java.util.*;
import java.util.concurrent.*;

// Question 15: Explain the differences between Collection and Collections in java.util.
// Answer: Collection is an interface representing a group of objects; Collections is a utility class with static methods such as sort, shuffle, reverse, and frequency.
class Question15 {
    public static void main(String[] args) {
        List<Integer> x=new ArrayList<>(List.of(3,1,2)); Collections.sort(x); System.out.println(x);
    }
}
