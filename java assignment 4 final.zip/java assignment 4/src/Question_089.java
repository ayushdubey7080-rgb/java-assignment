import java.util.*;
import java.util.concurrent.*;

// Question 89: Create a ConcurrentHashMap and demonstrate how it handles concurrent modifications.
// Answer: ConcurrentHashMap supports thread-safe concurrent access with high concurrency; it does not allow null keys or values. Iterators are weakly consistent.
class Question89 {
    public static void main(String[] args) {
        ConcurrentMap<String,Integer> m=new ConcurrentHashMap<>(); m.put("count",1); m.compute("count",(k,v)->v+1);
    }
}
