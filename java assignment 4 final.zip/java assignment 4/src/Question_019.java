import java.util.*;
import java.util.concurrent.*;

// Question 19: What is the difference between Collection and Map interfaces in Java?
// Answer: Collection stores individual elements; Map stores key-value pairs. Map is not a subtype of Collection and keys are unique.
class Question19 {
    public static void main(String[] args) {
        Map<Integer,String> m=new HashMap<>(); m.put(1,"One");
    }
}
