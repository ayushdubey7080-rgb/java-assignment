import java.util.*;
import java.util.concurrent.*;

// Question 86: How is Vector different from ArrayList in terms of thread safety?
// Answer: Vector is a legacy synchronized, thread-safe dynamic array; ArrayList is unsynchronized and generally faster. For modern concurrent use, consider other concurrent collections.
class Question86 {
    public static void main(String[] args) {
        Vector<Integer> v=new Vector<>(); v.add(1); ArrayList<Integer> a=new ArrayList<>(); a.add(1);
    }
}
