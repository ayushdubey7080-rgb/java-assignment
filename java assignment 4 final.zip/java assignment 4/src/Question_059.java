import java.util.*;
import java.util.concurrent.*;

// Question 59: How does HashMap handle collisions?
// Answer: A collision occurs when keys map to the same bucket. HashMap stores colliding entries in a bucket structure, using equals() to distinguish keys; modern Java can treeify heavily-collided buckets.
class Question59 {
    public static void main(String[] args) {
        Map<String,Integer> m=new HashMap<>(); m.put("one",1); m.put("two",2);
    }
}
