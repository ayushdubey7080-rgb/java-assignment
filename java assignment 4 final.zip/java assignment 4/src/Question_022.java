import java.util.*;
import java.util.concurrent.*;

// Question 22: What are the benefits of using the Collection Framework over arrays?
// Answer: Collections are resizable, provide ready-made data structures and algorithms, support generics, and simplify insertion, deletion, searching, and traversal.
class Question22 {
    public static void main(String[] args) {
        List<Integer> values=new ArrayList<>(); values.add(10);
    }
}
