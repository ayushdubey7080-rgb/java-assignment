import java.util.*;
import java.util.concurrent.*;

// Question 78: Write a program to check if a string is a palindrome using a Deque.
// Answer: Deque supports insertion/removal at both ends. ArrayDeque is efficient; palindrome check compares characters removed from both ends.
class Question78 {
    public static void main(String[] args) {
        Deque<Character> d=new ArrayDeque<>(); String s="level"; for(char c:s.toCharArray()) d.addLast(c); boolean ok=true; while(d.size()>1) if(!d.removeFirst().equals(d.removeLast())) ok=false; System.out.println(ok);
    }
}
