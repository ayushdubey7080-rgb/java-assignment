import java.util.*;
import java.util.concurrent.*;

// Question 13: What is the java.util package, and why is it essential in Java programming?
// Answer: java.util contains utility classes and collection types such as List, Map, Set, Arrays, Collections, Scanner, and Random.
class Question13 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(Arrays.asList("A","B")); System.out.println(list);
    }
}
