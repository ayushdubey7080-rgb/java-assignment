import java.util.*;
import java.util.concurrent.*;

// Question 45: What is the Set interface, and how is it different from List?
// Answer: List is ordered and permits duplicates; Set contains unique elements; Queue represents elements waiting for processing, commonly FIFO.
class Question45 {
    public static void main(String[] args) {
        List<String> l=new ArrayList<>(); Set<String> s=new HashSet<>(); Queue<String> q=new LinkedList<>();
    }
}
