import java.util.*;
import java.util.concurrent.*;

// Question 43: Write a program to sort an ArrayList of strings alphabetically and reverse alphabetically.
// Answer: Collections.sort sorts ascending; Collections.reverseOrder() sorts descending.
class Question43 {
    public static void main(String[] args) {
        List<String> names=new ArrayList<>(List.of("Ravi","Asha","Zoya")); Collections.sort(names); System.out.println(names); names.sort(Collections.reverseOrder()); System.out.println(names);
    }
}
