import java.util.*;
import java.util.concurrent.*;

// Question 23: Write a program to iterate over a List of integers using:
// Answer: A traditional for loop uses indices to access List elements.
class Question23 {
    public static void main(String[] args) {
        List<Integer> nums=List.of(10,20,30); for(int i=0;i<nums.size();i++) System.out.println(nums.get(i));
    }
}
