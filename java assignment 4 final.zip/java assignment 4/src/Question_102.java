import java.util.*;
import java.util.concurrent.*;

// Question 102: Write a program to sort a Map by its values using a custom Comparator.
// Answer: Sort entries by value using stream sorted with Map.Entry.comparingByValue, then collect into a LinkedHashMap to retain that order.
class Question102 {
    public static void main(String[] args) {
        Map<String,Integer> m=Map.of("A",3,"B",1,"C",2); m.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(System.out::println);
    }
}
