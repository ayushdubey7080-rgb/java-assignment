import java.util.*;
import java.util.concurrent.*;

// Question 71: Implement a simple program using Queue (with LinkedList) to simulate a ticket booking system.
// Answer: A Queue processes customers in FIFO order: first customer in is served first.
class Question71 {
    public static void main(String[] args) {
        Queue<String> q=new LinkedList<>(); q.offer("Customer 1"); q.offer("Customer 2"); while(!q.isEmpty()) System.out.println("Serving "+q.poll());
    }
}
