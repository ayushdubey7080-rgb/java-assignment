import java.util.*;
import java.util.concurrent.*;

// Question 84: What is the role of WeakHashMap in Java, and how is it different from HashMap?
// Answer: WeakHashMap uses weak keys; an entry may disappear after its key has no strong references and the garbage collector runs. GC timing is nondeterministic.
class Question84 {
    public static void main(String[] args) {
        Map<Object,String> m=new WeakHashMap<>(); Object key=new Object(); m.put(key,"value"); key=null; System.gc();
    }
}
