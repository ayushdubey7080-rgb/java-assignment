import java.util.*;
import java.util.concurrent.*;

// Question 97: Create an unmodifiable List using Collections.unmodifiableList() and show what happens when you try to modify it.
// Answer: unmodifiableList returns a read-only view; attempts to modify through it throw UnsupportedOperationException. Changes to the original backing list may still appear.
class Question97 {
    public static void main(String[] args) {
        List<String> original=new ArrayList<>(List.of("A")); List<String> view=Collections.unmodifiableList(original); try{view.add("B");}catch(UnsupportedOperationException ex){System.out.println("Cannot modify");}
    }
}
