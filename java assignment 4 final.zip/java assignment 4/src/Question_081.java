import java.util.*;
import java.util.concurrent.*;

// Question 81: How is the Deque interface different from the Queue interface?
// Answer: Deque supports insertion/removal at both ends. ArrayDeque is efficient; palindrome check compares characters removed from both ends.
class Question81 {
    public static void main(String[] args) {
        Deque<Character> d=new ArrayDeque<>(); String s="level"; for(char c:s.toCharArray()) d.addLast(c); boolean ok=true; while(d.size()>1) if(!d.removeFirst().equals(d.removeLast())) ok=false; System.out.println(ok);
    }
}
