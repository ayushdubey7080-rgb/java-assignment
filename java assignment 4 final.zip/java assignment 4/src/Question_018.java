import java.util.*;
import java.util.concurrent.*;

// Question 18: What are the key interfaces in the Java Collection Framework, and how are they related?
// Answer: The framework provides standard interfaces, implementations, algorithms, generics, iteration, and reusable data structures. Core hierarchy: Iterable -> Collection -> List/Set/Queue; Map is separate.
class Question18 {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<>(); Set<Integer> set=new HashSet<>(); Queue<Integer> queue=new LinkedList<>();
    }
}
