import java.util.*;
import java.util.concurrent.*;

// Question 99: Write a program to find the frequency of elements in a list using Collections.frequency().
// Answer: Collections.frequency counts occurrences of a target element.
class Question99 {
    public static void main(String[] args) {
        List<String> l=List.of("a","b","a"); System.out.println(Collections.frequency(l,"a"));
    }
}
