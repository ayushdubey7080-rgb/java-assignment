import java.util.*;
import java.util.concurrent.*;

// Question 111: Write a program to implement a simple banking system using Map to store customer IDs and their account balances.
// Answer: A Map associates customer IDs with balances. Validate withdrawals and update balances safely.
class Question111 {
    public static void main(String[] args) {
        Map<Integer,Double> accounts=new HashMap<>(); accounts.put(101,5000.0); accounts.merge(101,-500.0,Double::sum); System.out.println(accounts);
    }
}
