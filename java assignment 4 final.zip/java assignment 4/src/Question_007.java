import java.util.*;

// Question 7: Write a generic class Pair<K, V> that holds two values of any types, K and V. Include methods to get and set the values.
// Answer: Pair<K,V> stores two independently typed values.
class Pair<K,V>{ K key; V value; Pair(K k,V v){key=k;value=v;} K getKey(){return key;} V getValue(){return value;} void setKey(K k){key=k;} void setValue(V v){value=v;} }

class Question7 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
