import java.util.*;
import java.util.concurrent.*;

// Question 98: Write a program to perform a binary search on a List using the Collections.binarySearch() method.
// Answer: binarySearch requires a list sorted according to the same ordering; it returns the index or a negative insertion-point encoding.
class Question98 {
    public static void main(String[] args) {
        List<Integer> l=new ArrayList<>(List.of(1,3,5,7)); System.out.println(Collections.binarySearch(l,5));
    }
}
