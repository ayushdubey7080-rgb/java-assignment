import java.util.*;
import java.util.concurrent.*;

// Question 50: Write a program to demonstrate the uniqueness property of HashSet by attempting to add duplicate elements.
// Answer: HashSet has no guaranteed iteration order; LinkedHashSet preserves insertion order; TreeSet stores unique elements in sorted order. Set rejects duplicates.
class Question50 {
    public static void main(String[] args) {
        Set<Integer> s=new TreeSet<>(List.of(5,2,4,2)); System.out.println(s);
    }
}
