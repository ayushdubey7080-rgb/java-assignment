import java.util.*;

// Question 4: How do bounded type parameters work in generics? Write a generic class that accepts only subclasses of Number.
// Answer: A bound restricts a type parameter. T extends Number permits Number and its subclasses.
class NumericBox<T extends Number> { private T value; NumericBox(T v){value=v;} double asDouble(){return value.doubleValue();} }

class Question4 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
