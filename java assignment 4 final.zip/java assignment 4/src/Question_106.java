import java.util.*;
import java.util.concurrent.*;

// Question 106: Write a program to count the frequency of characters in a string using a HashMap.
// Answer: Use HashMap<Character,Integer> and merge each character count.
class Question106 {
    public static void main(String[] args) {
        String s="banana"; Map<Character,Integer> f=new HashMap<>(); for(char c:s.toCharArray()) f.merge(c,1,Integer::sum); System.out.println(f);
    }
}
