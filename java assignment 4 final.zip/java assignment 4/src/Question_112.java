import java.util.*;
import java.util.concurrent.*;

// Question 112: Use a WeakHashMap to demonstrate how entries are garbage-collected when keys are no longer strongly referenced.
// Answer: WeakHashMap uses weak keys; an entry may disappear after its key has no strong references and the garbage collector runs. GC timing is nondeterministic.
class Question112 {
    public static void main(String[] args) {
        Map<Object,String> m=new WeakHashMap<>(); Object key=new Object(); m.put(key,"value"); key=null; System.gc();
    }
}
