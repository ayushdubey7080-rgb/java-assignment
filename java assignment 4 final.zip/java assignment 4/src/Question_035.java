import java.util.*;
import java.util.concurrent.*;

// Question 35: Add elements to the list.
// Answer: Use add() to insert, remove(value) or remove(index) to delete, set(index,value) to replace, and print the list after each operation.
class Question35 {
    public static void main(String[] args) {
        List<String> l=new ArrayList<>(List.of("A","B")); l.add("C"); System.out.println(l); l.remove("B"); System.out.println(l); l.set(0,"X"); System.out.println(l);
    }
}
