import java.util.*;
import java.util.concurrent.*;

// Question 58: What is the difference between HashMap, LinkedHashMap, and TreeMap?
// Answer: TreeMap stores keys in their natural or Comparator-defined sorted order.
class Question58 {
    public static void main(String[] args) {
        Map<Integer,String> m=new TreeMap<>(); m.put(3,"C"); m.put(1,"A"); m.put(2,"B"); System.out.println(m);
    }
}
