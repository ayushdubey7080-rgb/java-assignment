import java.util.*;
import java.util.concurrent.*;

// Question 94: What are some commonly used methods in the Collections utility class?
// Answer: Common methods include sort, reverse, shuffle, min, max, frequency, binarySearch, copy, fill, and unmodifiableList.
class Question94 {
    public static void main(String[] args) {
        List<Integer> l=new ArrayList<>(List.of(3,1,2)); Collections.shuffle(l); Collections.sort(l);
    }
}
