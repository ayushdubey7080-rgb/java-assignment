import java.util.*;
import java.util.concurrent.*;

// Question 113: Create a program to implement a book catalog system using HashMap, where book titles are the keys and author names are the values. Allow searching by title.
// Answer: Use a HashMap with title as key and author as value; get(title) searches the catalog.
class Question113 {
    public static void main(String[] args) {
        Map<String,String> books=new HashMap<>(); books.put("1984","George Orwell"); System.out.println(books.getOrDefault("1984","Not found"));
    }
}
