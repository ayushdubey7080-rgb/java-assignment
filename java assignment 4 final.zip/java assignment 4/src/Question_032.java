import java.util.*;
import java.util.concurrent.*;

// Question 32: What is the role of the Vector class, and how does it differ from ArrayList?
// Answer: Vector is a legacy synchronized, thread-safe dynamic array; ArrayList is unsynchronized and generally faster. For modern concurrent use, consider other concurrent collections.
class Question32 {
    public static void main(String[] args) {
        Vector<Integer> v=new Vector<>(); v.add(1); ArrayList<Integer> a=new ArrayList<>(); a.add(1);
    }
}
