import java.util.*;
import java.util.concurrent.*;

// Question 16: What is the role of the Iterator interface in the java.util package?
// Answer: java.util contains utility classes and collection types such as List, Map, Set, Arrays, Collections, Scanner, and Random.
class Question16 {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>(Arrays.asList("A","B")); System.out.println(list);
    }
}
