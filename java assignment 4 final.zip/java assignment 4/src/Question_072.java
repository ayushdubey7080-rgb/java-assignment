import java.util.*;
import java.util.concurrent.*;

// Question 72: Use a PriorityQueue to store a list of tasks with priorities. Add tasks, remove the highest-priority task, and print the queue.
// Answer: PriorityQueue removes elements according to priority/natural ordering, not insertion order. By default, smallest value is removed first.
class Question72 {
    public static void main(String[] args) {
        PriorityQueue<Integer> pq=new PriorityQueue<>(List.of(5,1,3)); while(!pq.isEmpty()) System.out.println(pq.poll());
    }
}
