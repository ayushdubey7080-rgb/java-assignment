import java.util.*;

// Question 11: Implement a generic class MinMaxFinder<T extends Comparable
// Answer: Comparable provides natural ordering; compareTo determines which item is smaller/larger.
class MinMaxFinder<T extends Comparable<T>> { T min(List<T> xs){return Collections.min(xs);} T max(List<T> xs){return Collections.max(xs);} }

class Question11 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
