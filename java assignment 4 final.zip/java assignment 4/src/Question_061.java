import java.util.*;
import java.util.concurrent.*;

// Question 61: What is the difference between Hashtable and HashMap? Why is Hashtable considered legacy?
// Answer: HashMap is unsynchronized and allows one null key and null values. Hashtable is legacy synchronized and disallows null keys/values.
class Question61 {
    public static void main(String[] args) {
        Map<String,Integer> map=new HashMap<>(); map.put(null,1);
    }
}
