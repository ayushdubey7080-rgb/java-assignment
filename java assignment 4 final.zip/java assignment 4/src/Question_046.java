import java.util.*;
import java.util.concurrent.*;

// Question 46: What is the difference between HashSet, LinkedHashSet, and TreeSet in Java?
// Answer: HashSet has no guaranteed iteration order; LinkedHashSet preserves insertion order; TreeSet stores unique elements in sorted order. Set rejects duplicates.
class Question46 {
    public static void main(String[] args) {
        Set<Integer> s=new TreeSet<>(List.of(5,2,4,2)); System.out.println(s);
    }
}
