import java.util.*;
import java.util.concurrent.*;

// Question 68: Write a program to demonstrate the sorted order of keys in TreeMap by adding unsorted key-value pairs.
// Answer: TreeMap stores keys in their natural or Comparator-defined sorted order.
class Question68 {
    public static void main(String[] args) {
        Map<Integer,String> m=new TreeMap<>(); m.put(3,"C"); m.put(1,"A"); m.put(2,"B"); System.out.println(m);
    }
}
