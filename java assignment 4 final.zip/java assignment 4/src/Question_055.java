import java.util.*;
import java.util.concurrent.*;

// Question 55: Write a program to iterate over a LinkedHashSet and explain its order-preserving property.
// Answer: HashSet has no guaranteed iteration order; LinkedHashSet preserves insertion order; TreeSet stores unique elements in sorted order. Set rejects duplicates.
class Question55 {
    public static void main(String[] args) {
        Set<Integer> s=new TreeSet<>(List.of(5,2,4,2)); System.out.println(s);
    }
}
