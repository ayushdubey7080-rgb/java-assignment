import java.util.*;
import java.util.concurrent.*;

// Question 30: What is the difference between ArrayList and LinkedList in terms of performance and usage?
// Answer: ArrayList uses a dynamic array: fast indexed access, slower insertion/removal in the middle. LinkedList uses nodes: slower indexing, but efficient changes at known ends/iterator positions. Benchmark results depend on workload.
class Question30 {
    public static void main(String[] args) {
        List<Integer> a=new ArrayList<>(); List<Integer> b=new LinkedList<>(); a.add(1); b.add(1);
    }
}
