import java.util.*;
import java.util.concurrent.*;

// Question 96: How can you make a collection thread-safe using the Collections class?
// Answer: Use synchronized wrappers such as Collections.synchronizedList(list). Synchronize on the wrapper while iterating.
class Question96 {
    public static void main(String[] args) {
        List<String> list=Collections.synchronizedList(new ArrayList<>()); list.add("Java"); synchronized(list){ for(String x:list) System.out.println(x); }
    }
}
