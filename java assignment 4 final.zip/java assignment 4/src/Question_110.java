import java.util.*;

// Question 110: Create a generic MultiMap<K, V> class that stores multiple values for a single key using a HashMap<K, List
// Answer: Store a List<V> for each key; computeIfAbsent creates the list before adding a value.
class MultiMap<K,V>{ Map<K,List<V>> map=new HashMap<>(); void put(K k,V v){map.computeIfAbsent(k,x->new ArrayList<>()).add(v);} List<V> get(K k){return map.getOrDefault(k,Collections.emptyList());} }

class Question110 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
