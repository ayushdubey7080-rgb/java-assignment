import java.util.*;
import java.util.concurrent.*;

// Question 20: Explain the differences between Set, List, and Queue in the Collection Framework.
// Answer: List is ordered and permits duplicates; Set contains unique elements; Queue represents elements waiting for processing, commonly FIFO.
class Question20 {
    public static void main(String[] args) {
        List<String> l=new ArrayList<>(); Set<String> s=new HashSet<>(); Queue<String> q=new LinkedList<>();
    }
}
