import java.util.*;
import java.util.concurrent.*;

// Question 14: What are the key features of the Collection Framework in java.util?
// Answer: The framework provides standard interfaces, implementations, algorithms, generics, iteration, and reusable data structures. Core hierarchy: Iterable -> Collection -> List/Set/Queue; Map is separate.
class Question14 {
    public static void main(String[] args) {
        List<Integer> list=new ArrayList<>(); Set<Integer> set=new HashSet<>(); Queue<Integer> queue=new LinkedList<>();
    }
}
