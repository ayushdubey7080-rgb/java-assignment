import java.util.*;
import java.util.concurrent.*;

// Question 73: Write a program to implement a Stack using the Stack class. Perform operations like push, pop, peek, and check if it is empty.
// Answer: Stack extends Vector and follows LIFO. It is legacy; Deque/ArrayDeque is generally recommended.
class Question73 {
    public static void main(String[] args) {
        Deque<Integer> stack=new ArrayDeque<>(); stack.push(1); stack.push(2); System.out.println(stack.pop());
    }
}
