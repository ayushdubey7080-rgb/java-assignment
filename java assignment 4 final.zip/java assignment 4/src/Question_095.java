import java.util.*;
import java.util.concurrent.*;

// Question 95: Write a program to shuffle and sort an ArrayList using methods from the Collections class.
// Answer: Collections.shuffle randomizes order; Collections.sort orders elements naturally.
class Question95 {
    public static void main(String[] args) {
        List<Integer> l=new ArrayList<>(List.of(1,2,3,4)); Collections.shuffle(l); System.out.println(l); Collections.sort(l); System.out.println(l);
    }
}
