import java.util.*;
import java.util.concurrent.*;

// Question 6: How do raw types differ from parameterized types in generics, and why should raw types be avoided?
// Answer: A raw type omits generic arguments (List); a parameterized type specifies them (List<String>). Raw types bypass checks and can cause ClassCastException; prefer parameterized types.
class Question6 {
    public static void main(String[] args) {
        List<String> safe = new ArrayList<>(); safe.add("hello");
    }
}
