import java.util.*;
import java.util.concurrent.*;

// Question 107: Create a program to store students’ grades in a TreeMap, with student names as keys and grades as values. Allow adding, removing, and querying grades.
// Answer: TreeMap stores keys in their natural or Comparator-defined sorted order.
class Question107 {
    public static void main(String[] args) {
        Map<Integer,String> m=new TreeMap<>(); m.put(3,"C"); m.put(1,"A"); m.put(2,"B"); System.out.println(m);
    }
}
