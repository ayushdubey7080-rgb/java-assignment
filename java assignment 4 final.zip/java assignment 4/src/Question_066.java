import java.util.*;
import java.util.concurrent.*;

// Question 66: KeySet
// Answer: keySet() iterates keys; entrySet() iterates key-value pairs and is usually preferred when both are needed.
class Question66 {
    public static void main(String[] args) {
        Map<Integer,String> m=Map.of(1,"A",2,"B"); for(Integer k:m.keySet()) System.out.println(k); for(var e:m.entrySet()) System.out.println(e.getKey()+"="+e.getValue());
    }
}
