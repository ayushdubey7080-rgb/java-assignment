import java.util.*;
import java.util.concurrent.*;

// Question 83: Write a program to implement a simple Queue using the LinkedList class.
// Answer: A Queue processes customers in FIFO order: first customer in is served first.
class Question83 {
    public static void main(String[] args) {
        Queue<String> q=new LinkedList<>(); q.offer("Customer 1"); q.offer("Customer 2"); while(!q.isEmpty()) System.out.println("Serving "+q.poll());
    }
}
