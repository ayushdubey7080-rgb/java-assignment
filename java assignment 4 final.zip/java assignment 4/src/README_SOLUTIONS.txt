JAVA ASSIGNMENT 4 — SOLVED SOURCE FILES

Each Question_NNN.java file contains a concise answer/explanation in comments and a Java example.
Some theory questions are answered in comments and paired with a small demonstration.

Compile a file from this folder:
    javac Question_002.java
    java Question2

Note: Use a JDK (Java 8+; some examples use List.of and require Java 9+).
