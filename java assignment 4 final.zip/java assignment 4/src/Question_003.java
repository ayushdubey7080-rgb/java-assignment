import java.util.*;

// Question 3: Explain the syntax for creating a user-defined generic class in Java. Provide an example.
// Answer: Declare a type parameter after the class name, e.g. class Box<T>. Use T for fields and method parameters/returns; instantiate with Box<String>.
class Box<T> { private T value; Box(T value){ this.value=value; } T get(){ return value; } }

class Question3 {
    public static void main(String[] args) {
        
        System.out.println("See class implementation above; instantiate it with the required type.");
    }
}
