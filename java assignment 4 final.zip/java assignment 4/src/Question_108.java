import java.util.*;
import java.util.concurrent.*;

// Question 108: Write a program to merge two PriorityQueue objects and sort the resulting queue.
// Answer: PriorityQueue removes elements according to priority/natural ordering, not insertion order. By default, smallest value is removed first.
class Question108 {
    public static void main(String[] args) {
        PriorityQueue<Integer> pq=new PriorityQueue<>(List.of(5,1,3)); while(!pq.isEmpty()) System.out.println(pq.poll());
    }
}
