import java.util.*;
import java.util.concurrent.*;

// Question 21: What is the significance of the Iterable interface, and how is it used in the Collection Framework?
// Answer: Iterable declares iterator() and enables enhanced for loops. Collection extends Iterable.
class Question21 {
    public static void main(String[] args) {
        for(String s: List.of("Java","Collections")) System.out.println(s);
    }
}
