import java.util.*;
import java.util.concurrent.*;

// Question 67: EntrySet
// Answer: keySet() iterates keys; entrySet() iterates key-value pairs and is usually preferred when both are needed.
class Question67 {
    public static void main(String[] args) {
        Map<Integer,String> m=Map.of(1,"A",2,"B"); for(Integer k:m.keySet()) System.out.println(k); for(var e:m.entrySet()) System.out.println(e.getKey()+"="+e.getValue());
    }
}
