import java.util.*;
import java.util.concurrent.*;

// Question 29: What is the List interface, and how does it differ from the Set interface?
// Answer: List is ordered and permits duplicates; Set contains unique elements; Queue represents elements waiting for processing, commonly FIFO.
class Question29 {
    public static void main(String[] args) {
        List<String> l=new ArrayList<>(); Set<String> s=new HashSet<>(); Queue<String> q=new LinkedList<>();
    }
}
