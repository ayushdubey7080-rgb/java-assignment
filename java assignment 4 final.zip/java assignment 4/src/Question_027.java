import java.util.*;

// Question 27: Write a generic method to print all elements of any Collection (e.g., List, Set, Queue).
// Answer: A wildcard Collection<?> lets the method print elements from collections of any element type.
class Question27 {
    static void printAll(Collection<?> c){ for(Object x:c) System.out.println(x); }
    public static void main(String[] args) {
        System.out.println("Generic helper method is defined above.");
    }
}
